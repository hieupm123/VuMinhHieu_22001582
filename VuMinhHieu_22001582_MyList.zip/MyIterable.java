package hus.oop.midterm.mylist;

public interface MyIterable {
    MyIterator iterator();
}
